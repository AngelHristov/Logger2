﻿namespace LoggerLibrary.Layouts.Contracts
{
    public interface ILayout
    {
        string Format { get; }
    }
}
